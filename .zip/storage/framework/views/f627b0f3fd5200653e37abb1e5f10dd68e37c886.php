
<?php $__env->startSection('title','dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
            <div class="col-md-7">
                <div class="p-5">
                    <div class="text">
                        <h1 class="h4 text-gray-900 mb-4">Tambah Data Pembayaran</h1>
                    </div>
                    <form class="user" action="/admin/insert_pembayaran" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" name="id" id="exampleInputEmail"
                                placeholder="id" required>
                        </div>
                        
                        <div class="form-group">
                            <input type="date" class="form-control form-control-user" name="tanggal" id="exampleInputEmail"
                                placeholder="tanggal" required>
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" name="bulan_bayar" id="exampleInputEmail"
                                placeholder="bulan bayar" required>
                        </div>
                        
                        <div class="form-group">
                            <input type="number" class="form-control form-control-user" name="biaya_admin" id="exampleInputEmail"
                                placeholder="biaya admin" required>
                        </div>

                        

                        <button type="submit" class="btn btn-primary">Tambahkan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/include/app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\bayarlistrik\resources\views/admin/page/pembayaran/tambah_pembayaran.blade.php ENDPATH**/ ?>