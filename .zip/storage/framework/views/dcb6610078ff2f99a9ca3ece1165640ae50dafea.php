
<?php $__env->startSection('title','dashboard'); ?>

<?php $__env->startSection('content'); ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Pembayaran</h1>


                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>

                                        <tr>
                                            <th>id pembayaran</th>
                                            <th>Nama</th>
                                            <th>Tanggal</th>
                                            <th>Jumlah Bayar</th>
                                            <th>Biaya Admin</th>
                                            <th>Total Biaya</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                            <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                    

                                        <tr>
                                            <td><?php echo e($row->id_pembayaran); ?></td>
                                            <td><?php echo e($row->name); ?></td>
                                            <td><?php echo e($row->tanggal); ?></td>
                                            <td>Rp.<?php echo e(number_format($row->jumlah_bayar)); ?></td>
                                            <td>Rp.<?php echo e(number_format($row->biaya_admin)); ?></td>
                                            <td><b style="color:rgb(38, 0, 255);"> Rp.<?php echo e(number_format($row->biaya_admin + $row->jumlah_bayar)); ?></b></td>
                                            <td>
                                                <?php
                                                    $t = time() - $row->time_stop;
                                                ?>
                                                <?php if($t >= 86400): ?>
                                                    cannot undo!
                                                <?php else: ?>
                                                <a href="undo/<?php echo e($row->id_pembayaran); ?>/<?php echo e($row->id_tagihan); ?>" class="btn btn-warning" onclick="return confirm('Apakah belum bayar?')" >undo</a>
                                                    
                                                <?php endif; ?>
                                                

                                            </td>
                                        </tr>           
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/include/app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\bayarlistrik\resources\views/admin/page/pembayaran/view_pembayaran.blade.php ENDPATH**/ ?>