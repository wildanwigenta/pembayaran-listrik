
<?php $__env->startSection('title','dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
            <div class="col-md-7">
                <div class="p-5">
                    <div class="text">
                        <h1 class="h4 text-gray-900 mb-4">Edit Data User</h1>
                    </div>
                    <form class="user" action="/admin/update_user/<?php echo e($user->id); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" name="id" id="exampleInputEmail"
                                placeholder="" value="<?php echo e($user->id); ?>" hidden>
                        </div>

                        <div class="form-group mb-2">
                            <select name="level" id="" class="form-control">
                                <option value="pelanggan" <?php if( $user->level  == "pelanggan"): ?> selected <?php endif; ?>>pelanggan</option>
                                <option value="admin" <?php if( $user->level  == "admin"): ?> selected <?php endif; ?>>admin</option>
                                <option value="petugas" <?php if( $user->level  == "petugas"): ?> selected <?php endif; ?>>petugas</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" name="name" id="exampleInputEmail"
                                placeholder="name" value="<?php echo e($user->name); ?>" required>
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" name="email" id="exampleInputEmail"
                                placeholder="email" value="<?php echo e($user->email); ?>" required>
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" name="password" id="exampleInputEmail"
                                placeholder="password" required>
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" name="alamat" id="exampleInputEmail"
                                placeholder="alamat" value="<?php echo e($user->alamat); ?>" required>
                        </div>

                        <div class="form-group">
                            <input type="number" class="form-control form-control-user" name="kode_tarif" id="exampleInputEmail"
                                placeholder="kode tarif" value="<?php echo e($user->kode_tarif); ?>" required>
                        </div>

                        <div class="form-group">
                            <input type="number" class="form-control form-control-user" name="nometer" id="exampleInputEmail"
                                placeholder="nometer" value="<?php echo e($user->nometer); ?>" required>
                        </div>

                        

                        <button type="submit" class="btn btn-primary">Edit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/include/app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\bayarlistrik\resources\views/admin/page/user/edit_user.blade.php ENDPATH**/ ?>