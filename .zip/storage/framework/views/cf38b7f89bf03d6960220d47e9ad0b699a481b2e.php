
<?php $__env->startSection('title','dashboard'); ?>

<?php $__env->startSection('content'); ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Tagihan</h1>


                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <?php if(Auth::user()->level=='petugas'): ?>
                                <h6 class="m-0 font-weight-bold text-primary">
                                    <a href="/petugas/tambah_tagihan" class="btn btn-primary">tambah</a>
                                </h6>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        
                                        <tr>
                                            <th>id tagihan</th>
                                            <th>Nama Pengguna</th>
                                            <th>Bulan</th>
                                            <th>Tahun</th>
                                            <th>Jumlah Meter</th>
                                            <th>Total Biaya</th>
                                            <?php if(Auth::user()->level=='admin'): ?>                                              
                                                <th>Status</th>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->level=='admin'): ?>
                                                <th>Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                            <?php $__currentLoopData = $tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                    

                                        <tr>
                                            <td><?php echo e($row->id_tagihan); ?></td>
                                            <td><?php echo e($row->name); ?></td>
                                            <td><?php echo e($row->bulan); ?></td>
                                            <td><?php echo e($row->tahun); ?></td>
                                            <td><?php echo e($row->jumlah_meter); ?> KWH</td>
                                            <td style="color:blue">Rp.<?php echo e(number_format($row->jumlah_meter * ($row->kode_tarif == 1 ? 1352 : 1467))); ?></td>
                                            <?php if(Auth::user()->level=='admin'): ?>
                                                <td><a href="/admin/confirm_status/<?php echo e($row->id_tagihan); ?>" class="btn btn-<?php echo e($row->status == 'belum_bayar' ? 'secondary' : 'success disabled'); ?> " onclick="return confirm('Apakah sudah bayar?')" ><?php echo e($row->status); ?></a></td>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->level=='admin'): ?>
                                                <td>
                                                    <?php if($row->status == 'belum_bayar'): ?>
                                                        <a href="/admin/edit_tagihan/<?php echo e($row->id_tagihan); ?>" class= "btn btn-warning">Edit</a>
                                                        <a href="/admin/delete_tagihan/<?php echo e($row->id_tagihan); ?>" class="btn btn-danger" onclick="return confirm('Apakah anda yakin')">Delete</a>
                                                    <?php else: ?>
                                                        -- Lunas --
                                                    <?php endif; ?>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/include/app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\bayarlistrik\resources\views/admin/page/tagihan/view_tagihan.blade.php ENDPATH**/ ?>