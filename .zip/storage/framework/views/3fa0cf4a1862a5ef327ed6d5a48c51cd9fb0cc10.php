
<?php /**PATH D:\laragon\www\bayarlistrik\resources\views/auth/register.blade.php ENDPATH**/ ?>