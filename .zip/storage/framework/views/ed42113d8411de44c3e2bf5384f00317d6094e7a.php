
<?php $__env->startSection('title','dashboard'); ?>

<?php $__env->startSection('content'); ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Admin</h1>


                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <a href="/admin/tambah_user" class="btn btn-primary">tambah</a>
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>

                                        <tr>
                                            <th>Level</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Alamat</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                            <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                    

                                        <tr>
                                            <td><?php echo e($row->level); ?></td>
                                            <td><?php echo e($row->name); ?></td>
                                            <td><?php echo e($row->email); ?></td>
                                            <td><?php echo e($row->alamat); ?></td>
                                            <td>
                                                <a href="/admin/edit_user/<?php echo e($row->id); ?>" class= "btn btn-warning">Edit</a>
                                                <a href="/admin/delete_user/<?php echo e($row->id); ?>" class="btn btn-danger" onclick="return confirm('Apakah anda yakin')">Delete</a>
                                            </td>
                                        </tr>           
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">User</h1>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable2" width="100%" cellspacing="0">
                                    <thead>

                                        <tr>
                                            <th>Level</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Alamat</th>
                                            <th>Kode Tarif</th>
                                            <th>Nomor Meter</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                    

                                        <tr>
                                            <td><?php echo e($row->level); ?></td>
                                            <td><?php echo e($row->name); ?></td>
                                            <td><?php echo e($row->email); ?></td>
                                            <td><?php echo e($row->alamat); ?></td>
                                            <td><?php echo e($row->kode_tarif); ?></td>
                                            <td><?php echo e($row->nometer); ?></td>
                                            <td>
                                                <a href="/admin/edit_user/<?php echo e($row->id); ?>" class= "btn btn-warning">Edit</a>
                                                <a href="/admin/delete_user/<?php echo e($row->id); ?>" class="btn btn-danger" onclick="return confirm('Apakah anda yakin')">Delete</a>
                                            </td>
                                        </tr>           
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/include/app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\bayarlistrik\resources\views/admin/page/user/view_user.blade.php ENDPATH**/ ?>