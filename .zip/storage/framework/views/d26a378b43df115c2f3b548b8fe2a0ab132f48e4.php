<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>BayarListrik</title>
  <link href="<?php echo e(asset('sb-admin')); ?>/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('sb-admin')); ?>/css/sb-admin-2.min.css" rel="stylesheet">


  <style>
      html {
    height: 100%;
  }
  body {
    margin:0;
    padding:0;
    font-family: sans-serif;
    background: linear-gradient(#c9ddfc, #51c4f1);
  }

  .login-box {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 600px;
    padding: 40px;
    transform: translate(-50%, -50%);
    background: rgba(3, 2, 43, 0.5);
    box-sizing: border-box;
    box-shadow: 0 15px 25px rgba(0,0,0,.6);
    border-radius: 10px;
  }

  .login-box h2 {
    margin: 0 0 40px;
    padding: 0;
    color: #fff;
    text-align: center;
  }
  .login-box h5 {
    padding: 0;
    color: #fff;
    text-align: center;
  }
  .login-box p {
    padding: 0;
    color: rgb(0, 255, 213);
    text-align: center;
  }

  .login-box .user-box {
    position: relative;
  }

  .login-box .user-box input {
    width: 100%;
    padding: 10px 0;
    font-size: 16px;
    color: #fff;
    margin-bottom: 30px;
    border: none;
    border-bottom: 1px solid #fff;
    outline: none;
    background: transparent;
  }
  .login-box .user-box label {
    position: absolute;
    top:0;
    left: 0;
    padding: 10px 0;
    font-size: 16px;
    color: #fff;
    pointer-events: none;
    transition: .5s;
  }

  .login-box .user-box input:focus ~ label,
  .login-box .user-box input:valid ~ label {
    top: -20px;
    left: 0;
    color: #03e9f4;
    font-size: 12px;
  }

  .login-box form a {
    position: relative;
    display: inline-block;
    padding: 10px 20px;
    color: #03e9f4;
    font-size: 16px;
    text-decoration: none;
    text-transform: uppercase;
    overflow: hidden;
    transition: .5s;
    margin-top: 10px;
    letter-spacing: 4px
  }

  .login-box a.p:hover {
    background: #03e9f4;
    color: #fff;
    border-radius: 5px;
    box-shadow: 
                0 0 5px #03e9f4,
                0 0 25px #03e9f4,
                0 0 50px #03e9f4;
  }

  .login-box a.p span {
    position: absolute;
    display: block;
  }

  .login-box a.p span:nth-child(1) {
    top: 0;
    left: -100%;
    width: 100%;
    height: 2px;
    background: linear-gradient(90deg, transparent, #03e9f4);
    animation: btn-anim1 1s linear infinite;
  }

  @keyframes  btn-anim1 {
    0% {
      left: -100%;
    }
    50%,100% {
      left: 100%;
    }
  }

  .login-box a.p span:nth-child(2) {
    top: -100%;
    right: 0;
    width: 2px;
    height: 100%;
    background: linear-gradient(180deg, transparent, #03e9f4);
    animation: btn-anim2 1s linear infinite;
    animation-delay: .25s
  }

  @keyframes  btn-anim2 {
    0% {
      top: -100%;
    }
    50%,100% {
      top: 100%;
    }
  }

  .login-box a.p span:nth-child(3) {
    bottom: 0;
    right: -100%;
    width: 100%;
    height: 2px;
    background: linear-gradient(270deg, transparent, #03e9f4);
    animation: btn-anim3 1s linear infinite;
    animation-delay: .5s
  }

  @keyframes  btn-anim3 {
    0% {
      right: -100%;
    }
    50%,100% {
      right: 100%;
    }
  }

  .login-box a.p span:nth-child(4) {
    bottom: -100%;
    left: 0;
    width: 2px;
    height: 100%;
    background: linear-gradient(360deg, transparent, #03e9f4);
    animation: btn-anim4 1s linear infinite;
    animation-delay: .75s
  }

  @keyframes  btn-anim4 {
    0% {
      bottom: -100%;
    }
    50%,100% {
      bottom: 100%;
    }
  }
  </style>
</head>
<body>
  <div class="login-box">
      <h2>Selamat Datang <?php echo e(Auth::user()->name); ?></h2>
        <form>
          <?php if($tagihan->count() <= 0): ?>
            <h5>----- Tidak Ada Tagihan -----</h5><br>
          <?php else: ?>
            <h5>Lihat Tagihan Listrik Anda disini</h5><br>
          <?php $__currentLoopData = $tagihaninvoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
          <p>________ Tagihan Bulan <?php echo e($row->bulan); ?> Tahun <?php echo e($row->tahun); ?> ________</p>
          <center>
              <a href="/invoice/<?php echo e($row->id); ?>/<?php echo e($row->id_tagihan); ?>" class="p">
                  <span></span>
                  <span></span>
                  <span></span>   
                  <span></span>
                  Tagihan Anda
              </a>
          </center><br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </form>

        <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                  document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>

        <a href="/riwayat/<?php echo e(Auth::user()->id); ?>" class="btn btn-light float-right">Riwayat</a>
    </div>
  
</body>
</html>
<?php /**PATH D:\laragon\www\bayarlistrik\resources\views/frontend/index.blade.php ENDPATH**/ ?>